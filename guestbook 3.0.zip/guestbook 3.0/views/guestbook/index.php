<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\MessageSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Сообщения';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="messages-index">

    <h1>Список сообщений</h1>
    <p><?= Html::a('Новое сообщение', ['create'], ['class' => 'btn btn-success']) ?></p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'summary' => 'Сообщения c <b>{begin}</b> по <b>{end}</b> (всего: <b style="color: #007bff">{totalCount}</b>)',
        'columns' => [
            ['attribute' => 'id', 'label' => '№', 'filter' => false],
            ['attribute' => 'User', 'label' => 'Пользователь', 'value' => 'user.Login'],
            ['attribute' => 'Message', 'label' => 'Сообщение'],
            ['attribute' => 'Date', 'label' => 'Дата'],

            ['class' => 'yii\grid\ActionColumn',
                'header'=>'<b style="color: #007bff">Действия</b>',
            ],
        ],
    ]); ?>

</div>
