<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Message */

$this->title = 'Новое сообщение';
$this->params['breadcrumbs'][] = ['label' => 'Сообщения', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="messages-create">

    <?php
    if (Yii::$app->user->isGuest) echo "<h2>Для оставления сообщения необходима ".Html::a('авторизация', ['/site/login'])."!</h2>";
    else
        echo '<h1>'.Html::encode($this->title).'</h1>'.
        $this->render('_form', [
            'model' => $model,
        ])
    ?>
</div>
