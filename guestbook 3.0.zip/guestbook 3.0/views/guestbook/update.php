<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Message */

$this->title = 'Изменить сообщение ' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Сообщения', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Изменить';
?>
<div class="messages-update">

    <?php
    if ($model->User != Yii::$app->user->identity->id)
    {
        echo "<h2>Изменять можно только свои сообщения!</h2>";
    }
    else
        echo '<h1>'.Html::encode($this->title).'</h1>'.
            $this->render('_form', [
                'model' => $model,
            ])
    ?>

</div>
