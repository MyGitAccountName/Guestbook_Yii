<?php



use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

$this->title = 'Регистрация';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="site-signup">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin() ?>

    <?= $form->field($model, 'Login')->textInput(['class' => 'form-control col-lg-5']) ?>
    <?= $form->field($model, 'SurName')->textInput(['class' => 'form-control col-lg-5']) ?>
    <?= $form->field($model, 'Name')->textInput(['class' => 'form-control col-lg-5']) ?>
    <?= $form->field($model, 'Password')->passwordInput(['class' => 'form-control col-lg-5']) ?>
    <?= $form->field($model, 'Confirm')->passwordInput(['class' => 'form-control col-lg-5']) ?>
    <div class="form-group">
            <?= Html::submitButton('Зарегистрироваться', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end() ?>
</div>
