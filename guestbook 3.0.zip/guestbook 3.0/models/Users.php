<?php


namespace app\models;


class Users extends \yii\db\ActiveRecord
{

}