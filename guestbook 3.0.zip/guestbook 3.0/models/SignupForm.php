<?php


namespace app\models;

use yii\base\Model;

class SignupForm extends Model
{
    public $Login;
    public $Name = "";
    public $SurName = "";
    public $Password;
    public $Confirm;

    public function rules() {
        return [
            [['Login', 'Password', 'Confirm'], 'required', 'message' => 'Заполните поле!'],
            ['Login', 'unique', 'targetClass' => User::className(), 'message' => 'Этот логин уже занят!'],
            ['Login', 'validateLogin'],
            [['Name','SurName'], 'validateName'],
       //     ['Login', 'string', 'min' => 4, 'message' => 'Длина логина от 4 до 24 символов!'],
            ['Confirm', 'compare', 'compareAttribute' => 'Password', 'message' => 'Неверный пароль!'],
        ];
    }

    public function attributeLabels() {
        return [
            'Login' => 'Логин',
            'SurName' => 'Фамилия',
            'Name' => 'Имя',
            'Password' => 'Пароль',
            'Confirm' => 'Подтвердите пароль'
        ];
    }

    public function validateLogin($attribute, $params)
    {
        if (!$this->hasErrors()) {
            if (strlen($this->Login)<4 || strlen($this->Login)>24)
            {
                $errorMsg= 'Длина логина от 4 до 24 символов!';
                $this->addError('Login',$errorMsg);
            }
        }
    }

    public function validateName($attribute, $params)
    {
        if (!$this->hasErrors()) {
            if (strlen($this->Name)===1)
            {
                $errorMsg= 'Коротковато...';
                $this->addError('Name',$errorMsg);
            }
            if (strlen($this->SurName)===1)
            {
                $errorMsg= 'Коротковато...';
                $this->addError('SurName',$errorMsg);
            }
            if (!preg_match("/^[a-zа-яё-]{2,20}$/iu", $this->Name))
            {
                $errorMsg= 'Имена должны состоять из букв!';
                $this->addError('Name',$errorMsg);
            }
            if (!preg_match("/^[a-zа-яё-]{2,20}$/iu", $this->SurName))
            {
                $errorMsg= 'Фамилии должны состоять из букв!';
                $this->addError('SurName',$errorMsg);
            }
        }
    }

}
