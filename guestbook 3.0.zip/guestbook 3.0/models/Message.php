<?php


namespace app\models;

use Yii;

/**
 * This is the model class for table "Messages".
 *
 * @property int $id
 * @property string $Message
 * @property string $date
 */
class Message extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Messages';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Message'], 'required'],
            [['id'], 'integer'],
            [['Message'], 'string', 'max' => 52],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'id',
            'Message' => 'Message',
            'date' => 'Date',
        ];
    }
}
